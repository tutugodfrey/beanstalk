zip -r ../ts_gallery.zip . -x "*.DS_Store" -x "__MACOSX" -x "node_modules/*" -x ".git/*"
